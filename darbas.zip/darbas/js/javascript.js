function myFunction() {
    let x = document.getElementById("mMenu");
    if (x.style.display === "block") {
        x.style.display = "none"
    } else {
        x.style.display = "block"
    }
  }